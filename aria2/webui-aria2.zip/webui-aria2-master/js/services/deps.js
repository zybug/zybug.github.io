angular
  .module('webui.services.deps', [])
  .value('$', $)
  .value('$_', _)
  .value('$json', JSON);
